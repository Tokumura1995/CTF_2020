How to Play:
 Run to the goal across the tiles!
 Some of the tiles are fragile.

How to Move:
 W key     - Move forward
 A key     - Rotate left
 D key     - Rotate right
 Space key - Jump
